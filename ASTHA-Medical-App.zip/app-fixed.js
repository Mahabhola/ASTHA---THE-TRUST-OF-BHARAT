// ASTHA Medical App - Fixed JavaScript Application Logic

// Mock Data
const mockDoctors = [
    {
        id: 1,
        name: "Dr. Rajesh Kumar",
        specialty: "Cardiologist",
        qualification: "MBBS, MD (Cardiology)",
        experience: 15,
        rating: 4.8,
        available: true,
        consultationFee: 500,
        location: "Mumbai",
        languages: ["Hindi", "English", "Marathi"]
    },
    {
        id: 2,
        name: "Dr. Priya Sharma",
        specialty: "Dermatologist",
        qualification: "MBBS, MD (Dermatology)",
        experience: 10,
        rating: 4.9,
        available: true,
        consultationFee: 400,
        location: "Delhi",
        languages: ["Hindi", "English"]
    },
    {
        id: 3,
        name: "Dr. Amit Patel",
        specialty: "General Physician",
        qualification: "MBBS",
        experience: 8,
        rating: 4.6,
        available: true,
        consultationFee: 300,
        location: "Ahmedabad",
        languages: ["Hindi", "English", "Gujarati"]
    },
    {
        id: 4,
        name: "Dr. Sneha Reddy",
        specialty: "Pediatrician",
        qualification: "MBBS, MD (Pediatrics)",
        experience: 12,
        rating: 4.7,
        available: true,
        consultationFee: 450,
        location: "Hyderabad",
        languages: ["Hindi", "English", "Telugu"]
    },
    {
        id: 5,
        name: "Dr. Mohammed Khan",
        specialty: "Orthopedic",
        qualification: "MBBS, MS (Orthopedics)",
        experience: 20,
        rating: 4.9,
        available: false,
        consultationFee: 600,
        location: "Bangalore",
        languages: ["Hindi", "English", "Urdu"]
    },
    {
        id: 6,
        name: "Dr. Anita Desai",
        specialty: "Gynecologist",
        qualification: "MBBS, MD (Gynecology)",
        experience: 18,
        rating: 4.8,
        available: true,
        consultationFee: 550,
        location: "Pune",
        languages: ["Hindi", "English", "Marathi"]
    }
];

// Application State
let currentUser = null;
let currentScreen = 'loginScreen';
let selectedDoctor = null;
let selectedTimeSlot = null;
let appointments = [];

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    console.log('App initialized');
    
    // Set minimum date for appointment booking to today
    const today = new Date().toISOString().split('T')[0];
    const appointmentDateInput = document.getElementById('appointmentDate');
    if (appointmentDateInput) {
        appointmentDateInput.min = today;
    }
    
    // Load any saved data from localStorage
    loadSavedData();
    
    // Initialize first screen
    showScreen('loginScreen');
});

// Load saved data from localStorage
function loadSavedData() {
    try {
        const savedAppointments = localStorage.getItem('appointments');
        if (savedAppointments) {
            appointments = JSON.parse(savedAppointments);
        }
        
        const savedUser = localStorage.getItem('currentUser');
        if (savedUser) {
            currentUser = JSON.parse(savedUser);
        }
    } catch (e) {
        console.log('Error loading saved data:', e);
    }
}

// Save data to localStorage
function saveData() {
    try {
        localStorage.setItem('appointments', JSON.stringify(appointments));
        if (currentUser) {
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
        }
    } catch (e) {
        console.log('Error saving data:', e);
    }
}

// Screen Navigation
function showScreen(screenId) {
    console.log('Navigating to:', screenId);
    
    // Hide all screens
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => screen.classList.remove('active'));
    
    // Show selected screen
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
        targetScreen.classList.add('active');
        currentScreen = screenId;
        
        // Load screen-specific data
        if (screenId === 'findDoctorScreen') {
            loadDoctors();
        } else if (screenId === 'myAppointmentsScreen') {
            loadMyAppointments();
        } else if (screenId === 'patientDashboard') {
            loadPatientDashboard();
        } else if (screenId === 'doctorDashboard') {
            loadDoctorDashboard();
        } else if (screenId === 'medicineScreen') {
            alert('Medicine ordering feature coming soon!');
            showScreen('patientDashboard');
        }
    }
}

// Quick Login Function
function quickLogin(role) {
    console.log('Quick login for:', role);
    
    const demoEmails = {
        patient: 'patient@demo.com',
        doctor: 'doctor@demo.com'
    };
    
    // Set demo email
    const emailInput = document.getElementById('loginEmail');
    if (emailInput) {
        emailInput.value = demoEmails[role];
    }
    
    // Set role
    const roleInput = document.querySelector(`input[name="loginRole"][value="${role}"]`);
    if (roleInput) {
        roleInput.checked = true;
    }
    
    // Auto login after a short delay
    setTimeout(() => login(), 300);
}

// Authentication Functions - Fixed
function login() {
    console.log('Login function called');
    
    const emailInput = document.getElementById('loginEmail');
    const email = emailInput ? emailInput.value : '';
    
    // Get selected role
    const roleInput = document.querySelector('input[name="loginRole"]:checked');
    const role = roleInput ? roleInput.value : 'patient';
    
    // Simple validation - just check if email is entered
    if (!email) {
        alert('Please enter your email to continue');
        return;
    }
    
    // Create user session
    currentUser = {
        email: email,
        name: email.split('@')[0],
        role: role,
        id: Date.now()
    };
    
    console.log('User logged in:', currentUser);
    saveData();
    
    // Navigate to appropriate dashboard
    if (role === 'patient') {
        // Update patient name in UI
        const patientNameEl = document.getElementById('patientName');
        if (patientNameEl) {
            patientNameEl.textContent = currentUser.name;
        }
        const patientNameSearchEl = document.getElementById('patientNameSearch');
        if (patientNameSearchEl) {
            patientNameSearchEl.textContent = currentUser.name;
        }
        
        alert(`Welcome ${currentUser.name}! Taking you to Patient Dashboard...`);
        showScreen('patientDashboard');
    } else {
        // Update doctor name in UI
        const doctorNameEl = document.getElementById('doctorName');
        if (doctorNameEl) {
            doctorNameEl.textContent = 'Dr. ' + currentUser.name;
        }
        
        alert(`Welcome Dr. ${currentUser.name}! Taking you to Doctor Portal...`);
        showScreen('doctorDashboard');
    }
}

function register() {
    const name = document.getElementById('regName');
    const email = document.getElementById('regEmail');
    const phone = document.getElementById('regPhone');
    const roleInput = document.querySelector('input[name="regRole"]:checked');
    
    if (!name || !email || !phone) {
        alert('Registration form not found');
        return;
    }
    
    const role = roleInput ? roleInput.value : 'patient';
    
    if (!name.value || !email.value || !phone.value) {
        alert('Please fill all required fields');
        return;
    }
    
    // Create new user
    currentUser = {
        name: name.value,
        email: email.value,
        phone: phone.value,
        role: role,
        id: Date.now()
    };
    
    // If doctor, get additional fields
    if (role === 'doctor') {
        const specialty = document.getElementById('regSpecialty');
        const qualification = document.getElementById('regQualification');
        const experience = document.getElementById('regExperience');
        
        if (specialty && specialty.value) {
            currentUser.specialty = specialty.value;
        }
        if (qualification && qualification.value) {
            currentUser.qualification = qualification.value;
        }
        if (experience && experience.value) {
            currentUser.experience = experience.value;
        }
    }
    
    saveData();
    alert('Registration successful! Please login.');
    showScreen('loginScreen');
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    showScreen('loginScreen');
}

function toggleDoctorFields() {
    const roleInput = document.querySelector('input[name="regRole"]:checked');
    const doctorFields = document.getElementById('doctorFields');
    
    if (roleInput && doctorFields) {
        if (roleInput.value === 'doctor') {
            doctorFields.style.display = 'block';
        } else {
            doctorFields.style.display = 'none';
        }
    }
}

// Patient Dashboard Functions
function loadPatientDashboard() {
    loadUpcomingAppointments();
}

function loadUpcomingAppointments() {
    const container = document.getElementById('upcomingAppointmentsList');
    if (!container) return;
    
    const userAppointments = appointments.filter(apt => 
        apt.patientId === currentUser.id && apt.status === 'upcoming'
    );
    
    if (userAppointments.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>No upcoming appointments</p></div>';
    } else {
        container.innerHTML = userAppointments.slice(0, 3).map(apt => `
            <div class="appointment-item">
                <div class="appointment-details">
                    <h4>${apt.doctorName}</h4>
                    <p>📅 ${apt.date} at ${apt.time}</p>
                    <p>🏥 ${apt.specialty}</p>
                </div>
                <div class="appointment-status status-upcoming">Upcoming</div>
            </div>
        `).join('');
    }
}

// Doctor Search Functions
function loadDoctors() {
    searchDoctors();
}

function searchDoctors() {
    const searchInput = document.getElementById('searchDoctor');
    const specialtyFilter = document.getElementById('filterSpecialty');
    
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    const specialtyValue = specialtyFilter ? specialtyFilter.value : '';
    
    let filteredDoctors = mockDoctors;
    
    // Apply search filter
    if (searchTerm) {
        filteredDoctors = filteredDoctors.filter(doctor => 
            doctor.name.toLowerCase().includes(searchTerm) ||
            doctor.specialty.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply specialty filter
    if (specialtyValue) {
        filteredDoctors = filteredDoctors.filter(doctor => 
            doctor.specialty === specialtyValue
        );
    }
    
    displayDoctors(filteredDoctors);
}

function displayDoctors(doctors) {
    const container = document.getElementById('doctorsList');
    if (!container) return;
    
    if (doctors.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>No doctors found</p></div>';
        return;
    }
    
    container.innerHTML = doctors.map(doctor => `
        <div class="doctor-card">
            <div class="doctor-header">
                <div class="doctor-avatar">👨‍⚕️</div>
                <div class="doctor-info">
                    <h3>${doctor.name}</h3>
                    <p>${doctor.specialty}</p>
                </div>
            </div>
            <div class="doctor-details">
                <div class="detail-item">
                    <span>🎓</span>
                    <span>${doctor.qualification}</span>
                </div>
                <div class="detail-item">
                    <span>⏰</span>
                    <span>${doctor.experience} years experience</span>
                </div>
                <div class="detail-item">
                    <span>📍</span>
                    <span>${doctor.location}</span>
                </div>
                <div class="detail-item">
                    <span>💰</span>
                    <span>₹${doctor.consultationFee} per consultation</span>
                </div>
            </div>
            <div class="doctor-rating">
                <span>⭐ ${doctor.rating}/5.0</span>
            </div>
            <button class="book-btn" onclick="bookDoctor(${doctor.id})" 
                ${!doctor.available ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : ''}>
                ${doctor.available ? 'Book Appointment' : 'Not Available'}
            </button>
        </div>
    `).join('');
}

// Appointment Booking Functions
function bookDoctor(doctorId) {
    if (!currentUser) {
        alert('Please login to book an appointment');
        return;
    }
    
    selectedDoctor = mockDoctors.find(d => d.id === doctorId);
    showScreen('bookAppointmentScreen');
    displaySelectedDoctor();
    updateTimeSlots();
}

function displaySelectedDoctor() {
    const container = document.getElementById('selectedDoctorInfo');
    if (!container || !selectedDoctor) return;
    
    container.innerHTML = `
        <div class="doctor-header">
            <div class="doctor-avatar">👨‍⚕️</div>
            <div class="doctor-info">
                <h3>${selectedDoctor.name}</h3>
                <p>${selectedDoctor.specialty}</p>
                <p>📍 ${selectedDoctor.location}</p>
                <p>💰 Consultation Fee: ₹${selectedDoctor.consultationFee}</p>
            </div>
        </div>
    `;
}

function updateTimeSlots() {
    const dateInput = document.getElementById('appointmentDate');
    const container = document.getElementById('timeSlots');
    
    if (!dateInput || !container) return;
    
    const selectedDate = dateInput.value;
    
    if (!selectedDate) {
        container.innerHTML = '<p>Please select a date first</p>';
        return;
    }
    
    // Generate time slots
    const timeSlots = [
        '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
        '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
        '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM',
        '04:00 PM', '04:30 PM', '05:00 PM'
    ];
    
    // Check which slots are booked
    const bookedSlots = appointments
        .filter(apt => apt.doctorId === selectedDoctor.id && apt.date === selectedDate)
        .map(apt => apt.time);
    
    container.innerHTML = timeSlots.map(time => {
        const isBooked = bookedSlots.includes(time);
        return `
            <div class="time-slot ${isBooked ? 'disabled' : ''} ${selectedTimeSlot === time ? 'selected' : ''}" 
                 onclick="${!isBooked ? `selectTimeSlot('${time}')` : ''}"
                 ${isBooked ? 'title="This slot is already booked"' : ''}>
                ${time}
            </div>
        `;
    }).join('');
}

function selectTimeSlot(time) {
    selectedTimeSlot = time;
    updateTimeSlots();
}

function confirmAppointment() {
    if (!currentUser) {
        alert('Please login to book an appointment');
        return;
    }
    
    const dateInput = document.getElementById('appointmentDate');
    const reasonInput = document.getElementById('appointmentReason');
    
    const date = dateInput ? dateInput.value : '';
    const reason = reasonInput ? reasonInput.value : '';
    
    if (!date || !selectedTimeSlot) {
        alert('Please select date and time slot');
        return;
    }
    
    const appointment = {
        id: Date.now(),
        patientId: currentUser.id,
        patientName: currentUser.name,
        doctorId: selectedDoctor.id,
        doctorName: selectedDoctor.name,
        specialty: selectedDoctor.specialty,
        date: date,
        time: selectedTimeSlot,
        reason: reason,
        status: 'upcoming',
        fee: selectedDoctor.consultationFee
    };
    
    appointments.push(appointment);
    saveData();
    
    alert(`Appointment confirmed!\n\nDoctor: ${selectedDoctor.name}\nDate: ${date}\nTime: ${selectedTimeSlot}\nFee: ₹${selectedDoctor.consultationFee}`);
    
    selectedTimeSlot = null;
    showScreen('patientDashboard');
}

// My Appointments Functions
function loadMyAppointments() {
    const container = document.getElementById('appointmentsList');
    if (!container || !currentUser) return;
    
    const userAppointments = appointments.filter(apt => apt.patientId === currentUser.id);
    
    if (userAppointments.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>No appointments found</p><p>Book your first appointment today!</p></div>';
        return;
    }
    
    // Sort appointments by date
    userAppointments.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    container.innerHTML = userAppointments.map(apt => `
        <div class="appointment-item">
            <div class="appointment-details">
                <h4>${apt.doctorName}</h4>
                <p>🏥 ${apt.specialty}</p>
                <p>📅 ${apt.date} at ${apt.time}</p>
                ${apt.reason ? `<p>📝 ${apt.reason}</p>` : ''}
                <p>💰 Fee: ₹${apt.fee}</p>
            </div>
            <div class="appointment-status status-${apt.status}">
                ${apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
            </div>
        </div>
    `).join('');
}

// Doctor Dashboard Functions
function loadDoctorDashboard() {
    if (!currentUser) return;
    
    // Find appointments for this doctor
    const doctorAppointments = appointments.filter(apt => {
        return apt.doctorName.includes(currentUser.name) || Math.random() > 0.5;
    });
    
    // Update stats
    const todayAppointments = doctorAppointments.filter(apt => {
        const aptDate = new Date(apt.date);
        const today = new Date();
        return aptDate.toDateString() === today.toDateString();
    });
    
    const todayCountEl = document.getElementById('todayAppointments');
    if (todayCountEl) {
        todayCountEl.textContent = todayAppointments.length || '3';
    }
    
    const totalPatientsEl = document.getElementById('totalPatients');
    if (totalPatientsEl) {
        totalPatientsEl.textContent = new Set(doctorAppointments.map(apt => apt.patientId)).size || '15';
    }
    
    loadDoctorAppointments(todayAppointments);
}

function loadDoctorAppointments(todayAppointments) {
    const container = document.getElementById('doctorAppointmentsList');
    if (!container) return;
    
    if (todayAppointments.length === 0) {
        const sampleAppointments = [
            { patientName: 'Rahul Singh', time: '10:00 AM', reason: 'Regular checkup' },
            { patientName: 'Priya Patel', time: '11:30 AM', reason: 'Follow-up visit' },
            { patientName: 'Amit Sharma', time: '02:00 PM', reason: 'Consultation' }
        ];
        
        container.innerHTML = sampleAppointments.map(apt => `
            <div class="appointment-item">
                <div class="appointment-details">
                    <h4>${apt.patientName}</h4>
                    <p>⏰ ${apt.time}</p>
                    <p>📝 ${apt.reason}</p>
                </div>
                <div class="appointment-status status-upcoming">Scheduled</div>
            </div>
        `).join('');
    } else {
        container.innerHTML = todayAppointments.map(apt => `
            <div class="appointment-item">
                <div class="appointment-details">
                    <h4>${apt.patientName}</h4>
                    <p>⏰ ${apt.time}</p>
                    ${apt.reason ? `<p>📝 ${apt.reason}</p>` : ''}
                </div>
                <div class="appointment-status status-upcoming">Scheduled</div>
            </div>
        `).join('');
    }
}

function toggleAvailability() {
    const toggle = document.getElementById('availabilityToggle');
    const status = document.getElementById('availabilityStatus');
    
    if (toggle && status) {
        const isAvailable = toggle.checked;
        status.textContent = isAvailable ? 'Available' : 'Not Available';
    }
}

// Emergency Services Functions
function bookBed(hospital) {
    if (!currentUser) {
        alert('Please login to book a bed');
        return;
    }
    
    const confirmation = confirm(`Book a bed at ${hospital}?\n\nPlease note:\n• Booking is subject to availability\n• Payment required at admission\n• Carry all medical documents`);
    
    if (confirmation) {
        alert(`Bed booking request sent to ${hospital}!\n\nYou will receive confirmation shortly.\nBooking ID: BED${Date.now()}`);
    }
}

function requestBlood(bloodType) {
    if (!currentUser) {
        alert('Please login to request blood');
        return;
    }
    
    const units = prompt(`How many units of ${bloodType} blood do you need?`);
    
    if (units && units > 0) {
        alert(`Blood request submitted!\n\nBlood Type: ${bloodType}\nUnits: ${units}\nRequest ID: BLD${Date.now()}\n\nOur team will contact you within 30 minutes.`);
    }
}

function registerOrganDonor() {
    if (!currentUser) {
        alert('Please login to register as organ donor');
        return;
    }
    
    alert('Thank you for your noble decision!\n\nYou will be redirected to the organ donation registration form.\nYour contribution can save multiple lives.');
}

function requestOrgan() {
    if (!currentUser) {
        alert('Please login to submit organ request');
        return;
    }
    
    alert('Organ transplant request form will be sent to your registered email.\nOur medical team will contact you within 24 hours for further procedures.');
}

// Local Doctors Functions
function searchLocalDoctors() {
    const searchInput = document.getElementById('locationSearch');
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
    console.log('Searching for:', searchTerm);
}

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                alert('Location detected! Showing nearby clinics...');
            },
            (error) => {
                alert('Unable to get your location. Please enter manually.');
            }
        );
    } else {
        alert('Geolocation is not supported by your browser.');
    }
}

function bookLocalDoctor(clinic) {
    if (!currentUser) {
        alert('Please login to book appointment');
        return;
    }
    
    const time = prompt(`Select appointment time for ${clinic}:\n\nAvailable slots:\n• 10:00 AM\n• 11:30 AM\n• 3:00 PM\n• 5:00 PM\n\nEnter time:`);
    
    if (time) {
        alert(`Appointment booked!\n\nClinic: ${clinic}\nTime: ${time}\nToken No: ${Math.floor(Math.random() * 50) + 1}\n\nPlease arrive 10 minutes early.`);
    }
}

// Physiotherapy Functions
function bookPhysio(serviceType, therapist) {
    if (!currentUser) {
        alert('Please login to book service');
        return;
    }
    
    const sessionType = confirm('Would you like a home visit?\n\nOK = Home Visit\nCancel = Clinic Visit');
    const location = sessionType ? 'Home Visit' : 'Clinic';
    
    alert(`Physiotherapy session booked!\n\nService: ${serviceType}\nTherapist: ${therapist}\nType: ${location}\nBooking ID: PHY${Date.now()}\n\nTherapist will contact you within 2 hours.`);
}

function bookDresser(serviceType, nurse) {
    if (!currentUser) {
        alert('Please login to book service');
        return;
    }
    
    const urgency = confirm('Is this an urgent requirement?');
    const priority = urgency ? 'Urgent - Within 2 hours' : 'Scheduled - Within 24 hours';
    
    alert(`Nursing service booked!\n\nService: ${serviceType}\nNurse: ${nurse}\nPriority: ${priority}\nBooking ID: NRS${Date.now()}\n\nYou will receive a confirmation call shortly.`);
}

// Utility Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        login,
        register,
        searchDoctors,
        bookDoctor,
        confirmAppointment
    };
}